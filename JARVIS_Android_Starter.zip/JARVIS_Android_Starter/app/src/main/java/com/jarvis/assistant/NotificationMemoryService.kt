package com.jarvis.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

/**
 * Guarda solo las notificaciones de aplicaciones que el usuario seleccionó.
 * Android requiere que el usuario habilite manualmente el acceso de notificaciones.
 */
class NotificationMemoryService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val prefs = getSharedPreferences("jarvis_data", MODE_PRIVATE)
        val enabled = prefs.getStringSet("enabled_apps", setOf("com.whatsapp")) ?: setOf("com.whatsapp")
        if (!enabled.contains(sbn.packageName)) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val appLabel = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }

        synchronized(LOCK) {
            val old = try { JSONArray(prefs.getString("app_events", "[]")) } catch (_: Exception) { JSONArray() }
            val next = JSONArray()
            // Conservar como máximo 250 avisos para no crecer indefinidamente.
            val start = (old.length() - 249).coerceAtLeast(0)
            for (i in start until old.length()) next.put(old.getJSONObject(i))
            next.put(JSONObject()
                .put("app", appLabel)
                .put("package", sbn.packageName)
                .put("title", title.take(300))
                .put("body", text.take(1500))
                .put("time", sbn.postTime))
            prefs.edit().putString("app_events", next.toString()).apply()
        }
    }

    companion object { private val LOCK = Any() }
}
