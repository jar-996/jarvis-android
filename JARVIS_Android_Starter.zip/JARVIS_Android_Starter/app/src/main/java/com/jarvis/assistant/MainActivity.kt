package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Navy = Color(0xFF050A12)
private val Panel = Color(0xFF0C1725)
private val Cyan = Color(0xFF00D9FF)
private val Pale = Color(0xFFE8F7FF)
private val Muted = Color(0xFF8EA9BC)

private val supportedApps = listOf(
    "WhatsApp" to "com.whatsapp",
    "Telegram" to "org.telegram.messenger",
    "Instagram" to "com.instagram.android",
    "Gmail" to "com.google.android.gm",
    "Mensajes SMS" to "com.google.android.apps.messaging"
)

data class ChatMessage(val text: String, val fromJarvis: Boolean)
data class AppEvent(val app: String, val title: String, val body: String, val time: Long)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisApp(onSpeak = { speak(it) }) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("es", "PY")
            tts?.setSpeechRate(0.92f)
            tts?.setPitch(0.82f)
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JarvisApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis_data", Context.MODE_PRIVATE) }
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(loadMessages(prefs)) }
    var memories by remember { mutableStateOf(loadMemories(prefs)) }
    var appEvents by remember { mutableStateOf(loadAppEvents(prefs)) }
    var enabledApps by remember { mutableStateOf(loadEnabledApps(prefs)) }
    var showMemories by remember { mutableStateOf(false) }
    var showApps by remember { mutableStateOf(false) }
    var showAppHistory by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("SISTEMA EN LÍNEA · MODO LOCAL") }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
        status = if (spoken.isNullOrBlank()) "NO SE DETECTÓ VOZ" else "VOZ RECONOCIDA"
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeechRecognition(context, speechLauncher)
        else status = "PERMISO DE MICRÓFONO DENEGADO"
    }

    fun persist() {
        saveMessages(prefs, messages)
        saveMemories(prefs, memories)
        saveEnabledApps(prefs, enabledApps)
    }

    fun sendMessage(raw: String) {
        val userText = raw.trim()
        if (userText.isEmpty()) return
        val lower = userText.lowercase(Locale.ROOT)
        val response: String
        when {
            lower.startsWith("recuerda ") -> {
                val memory = userText.substringAfter("recuerda ").trim()
                if (memory.isNotBlank()) {
                    memories = (memories + memory).distinct().takeLast(100)
                    response = "Entendido. Guardé ese recuerdo en la memoria local de este dispositivo."
                } else response = "Decime qué querés que recuerde."
            }
            lower.contains("qué recuerdas") || lower.contains("que recuerdas") || lower.contains("mis recuerdos") -> {
                response = if (memories.isEmpty()) "Todavía no hay recuerdos guardados. Podés decir: ‘Recuerda que estoy trabajando en un proyecto’."
                else "Estos son tus recuerdos guardados: " + memories.takeLast(10).joinToString("; ")
            }
            lower.contains("whatsapp") || lower.contains("telegram") || lower.contains("instagram") ||
                lower.contains("gmail") || lower.contains("mensajes") || lower.contains("conversación") || lower.contains("conversacion") -> {
                appEvents = loadAppEvents(prefs)
                val matched = appEvents.filter { event ->
                    val label = event.app.lowercase(Locale.ROOT)
                    lower.contains(label) || (lower.contains("whatsapp") && label.contains("whatsapp")) ||
                        (lower.contains("telegram") && label.contains("telegram")) ||
                        (lower.contains("instagram") && label.contains("instagram")) ||
                        (lower.contains("gmail") && label.contains("gmail"))
                }.takeLast(5)
                response = if (matched.isEmpty()) {
                    "No encuentro notificaciones guardadas de esa aplicación. Verificá que esté seleccionada en Configurar apps y que hayas autorizado el acceso a notificaciones. Solo puedo recordar lo que Android me permita recibir; todavía no puedo leer todos los chats internos."
                } else "Esto es lo último que JARVIS guardó de las notificaciones: " + matched.joinToString(". ") {
                    "${it.app}, ${it.title}: ${it.body}"
                }
            }
            lower.contains("hora") -> response = "Puedo ayudarte a organizar tareas. Para consultar la hora exacta, revisá el reloj del dispositivo."
            lower.contains("hola") || lower.contains("buenas") -> response = "A tu servicio. Sistemas básicos operativos. ¿Qué necesitás?"
            lower.contains("quién eres") || lower.contains("quien eres") -> response = "Soy JARVIS, tu prototipo de asistente personal. Esta versión tiene memoria local y lectura opcional de notificaciones, pero todavía no está conectada a un modelo avanzado en línea."
            else -> response = "He recibido tu solicitud. Esta versión sigue siendo un prototipo local; todavía necesita conectar un modelo de IA para razonar sobre preguntas abiertas. Podés decir ‘Recuerda que…’ o consultar notificaciones guardadas de las apps autorizadas."
        }
        messages = (messages + ChatMessage(userText, false) + ChatMessage(response, true)).takeLast(200)
        input = ""
        status = "LISTO"
        persist()
        onSpeak(response)
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, onPrimary = Navy, background = Navy, surface = Panel, onSurface = Pale, secondary = Muted)) {
        Scaffold(
            containerColor = Navy,
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text("J.A.R.V.I.S.", fontWeight = FontWeight.Bold, color = Cyan, letterSpacing = 2.sp)
                        Text(status, fontSize = 10.sp, color = Muted, letterSpacing = 1.sp)
                    } },
                    actions = {
                        IconButton(onClick = { memories = loadMemories(prefs); showMemories = !showMemories }) {
                            Icon(Icons.Default.Memory, contentDescription = "Ver memoria", tint = Cyan)
                        }
                        IconButton(onClick = { enabledApps = loadEnabledApps(prefs); showApps = true }) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = "Configurar aplicaciones", tint = Cyan)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                )
            },
            bottomBar = {
                Row(Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().imePadding().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Dale una orden a JARVIS…", color = Muted) }, shape = RoundedCornerShape(18.dp), maxLines = 4,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { sendMessage(input) }),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Muted, focusedTextColor = Pale, unfocusedTextColor = Pale, cursorColor = Cyan)
                    )
                    IconButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startSpeechRecognition(context, speechLauncher)
                        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(Icons.Default.Mic, contentDescription = "Hablar", tint = Cyan) }
                    IconButton(onClick = { sendMessage(input) }) { Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Cyan) }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(Navy, Color(0xFF081522), Navy)))) {
                Box(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(92.dp).background(Cyan.copy(alpha = 0.08f), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(68.dp).background(Cyan.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
                            Text("J", color = Cyan, fontSize = 42.sp, fontWeight = FontWeight.Light)
                        }
                    }
                }

                if (showMemories) {
                    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("MEMORIA LOCAL", color = Cyan, fontWeight = FontWeight.Bold)
                            if (memories.isEmpty()) Text("No hay recuerdos guardados.", color = Muted)
                            else memories.takeLast(8).reversed().forEach { Text("• $it", color = Pale, modifier = Modifier.padding(top = 5.dp)) }
                            TextButton(onClick = { memories = emptyList(); persist() }) { Text("Borrar todos los recuerdos", color = Cyan) }
                        }
                    }
                }

                if (showAppHistory) {
                    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("NOTIFICACIONES RECORDADAS", color = Cyan, fontWeight = FontWeight.Bold)
                            if (appEvents.isEmpty()) Text("Todavía no hay notificaciones guardadas.", color = Muted)
                            else appEvents.takeLast(12).reversed().forEach { event ->
                                Text("${event.app} · ${event.title}", color = Cyan, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                                Text(event.body, color = Pale)
                            }
                            Text("Solo se guardan notificaciones recibidas después de activar el acceso; no es un lector de chats completos.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                            TextButton(onClick = { prefs.edit().remove("app_events").apply(); appEvents = emptyList() }) { Text("Borrar historial de notificaciones", color = Cyan) }
                        }
                    }
                }

                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        try { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (_: Exception) { status = "NO SE PUDO ABRIR AJUSTES" }
                    }, modifier = Modifier.weight(1f)) { Text("Permitir notificaciones", color = Cyan, fontSize = 12.sp) }
                    OutlinedButton(onClick = { appEvents = loadAppEvents(prefs); showAppHistory = !showAppHistory }, modifier = Modifier.weight(1f)) { Text("Ver historial", color = Cyan, fontSize = 12.sp) }
                }

                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (messages.isEmpty()) item {
                        Text("Sistemas listos. Escribí un mensaje o tocá el micrófono.\n\nProbá: ‘Recuerda que mi proyecto se llama JARVIS’ o ‘¿Qué notificaciones tengo de WhatsApp?’. Configurá las aplicaciones con el ícono superior.", color = Muted, modifier = Modifier.padding(12.dp))
                    }
                    items(messages) { message ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromJarvis) Arrangement.Start else Arrangement.End) {
                            Surface(color = if (message.fromJarvis) Panel else Color(0xFF073448), shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = if (message.fromJarvis) 4.dp else 16.dp, bottomEnd = if (message.fromJarvis) 16.dp else 4.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(if (message.fromJarvis) "JARVIS" else "TÚ", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(4.dp))
                                    Text(message.text, color = Pale)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showApps) {
            AlertDialog(
                onDismissRequest = { showApps = false },
                title = { Text("Aplicaciones que JARVIS puede recordar", color = Cyan) },
                text = {
                    Column {
                        Text("Elegí qué notificaciones querés guardar. Android te pedirá habilitar el acceso por separado.", color = Muted)
                        Spacer(Modifier.height(8.dp))
                        supportedApps.forEach { (label, packageName) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = enabledApps.contains(packageName), onCheckedChange = { checked ->
                                    enabledApps = if (checked) enabledApps + packageName else enabledApps - packageName
                                    saveEnabledApps(prefs, enabledApps)
                                })
                                Text(label, color = Pale)
                            }
                        }
                        Text("Se guarda el texto que aparezca en las notificaciones, que puede incluir datos privados. No se envía a un servidor en esta versión.", color = Muted, fontSize = 11.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { showApps = false }) { Text("Listo", color = Cyan) } },
                containerColor = Panel
            )
        }
    }
}

private fun startSpeechRecognition(context: Context, launcher: androidx.activity.result.ActivityResultLauncher<Intent>) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PY")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con JARVIS")
    }
    try { launcher.launch(intent) } catch (_: Exception) { }
}

private fun loadMessages(prefs: android.content.SharedPreferences): List<ChatMessage> = try {
    val array = JSONArray(prefs.getString("messages", "[]"))
    (0 until array.length()).map { i -> val obj = array.getJSONObject(i); ChatMessage(obj.getString("text"), obj.getBoolean("jarvis")) }
} catch (_: Exception) { emptyList() }

private fun saveMessages(prefs: android.content.SharedPreferences, messages: List<ChatMessage>) {
    val array = JSONArray(); messages.forEach { array.put(JSONObject().put("text", it.text).put("jarvis", it.fromJarvis)) }
    prefs.edit().putString("messages", array.toString()).apply()
}

private fun loadMemories(prefs: android.content.SharedPreferences): List<String> = try {
    val array = JSONArray(prefs.getString("memories", "[]")); (0 until array.length()).map { array.getString(it) }
} catch (_: Exception) { emptyList() }

private fun saveMemories(prefs: android.content.SharedPreferences, memories: List<String>) {
    val array = JSONArray(); memories.forEach { array.put(it) }; prefs.edit().putString("memories", array.toString()).apply()
}

private fun loadEnabledApps(prefs: android.content.SharedPreferences): Set<String> =
    prefs.getStringSet("enabled_apps", setOf("com.whatsapp"))?.toSet() ?: setOf("com.whatsapp")

private fun saveEnabledApps(prefs: android.content.SharedPreferences, apps: Set<String>) {
    prefs.edit().putStringSet("enabled_apps", apps.toSet()).apply()
}

private fun loadAppEvents(prefs: android.content.SharedPreferences): List<AppEvent> = try {
    val array = JSONArray(prefs.getString("app_events", "[]"))
    (0 until array.length()).map { i ->
        val obj = array.getJSONObject(i)
        AppEvent(obj.optString("app", "Aplicación"), obj.optString("title", "Notificación"), obj.optString("body", ""), obj.optLong("time", 0L))
    }
} catch (_: Exception) { emptyList() }
